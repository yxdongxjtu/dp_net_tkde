# -*- coding: utf-8 -*-
"""
Title: Code for < Synergistic Dual Proxies: Enhancing Cohesion and Separability in Deep Graph Clustering >
Description: Interface for Citeseer Dataset
"""

import os
import argparse
import random

import torch
import torch.nn.functional as F
import numpy as np
from tqdm import tqdm

from utils.data_process import load_data, get_class_num, random_aug
from utils.initialize import init_proxies
from utils.evaluate import eval_clustering_with_inter_proxy
from utils.proxy_update import update_eccs, update_pseudo_labels
from utils.model_helper import get_optimizer, exp_moving_average, cal_sim_feat2cen
from models.model import DPNet


def argument():
    parser = argparse.ArgumentParser(description="DP-Net")
    # Data settings
    parser.add_argument('--dataset', type=str, default='citeseer', help='Name of dataset.')
    parser.add_argument('--is2undirected', type=bool, default=False, help='Convert directed graph to undirected graph')
    parser.add_argument('--feat_mask_rate1', type=float, default=0.1, help='The rate of feature mask for view 1')
    parser.add_argument('--edge_mask_rate1', type=float, default=0.5, help='The rate of edge mask for view 1')
    parser.add_argument('--feat_mask_rate2', type=float, default=0.1, help='The rate of feature mask for view 2')
    parser.add_argument('--edge_mask_rate2', type=float, default=0.5, help='The rate of edge mask for view 2')
    # Architecture settings
    parser.add_argument('--enc_type', type=str, default='GCN', help='Encoder type.')
    parser.add_argument('--enc_hids_dim', type=list, default=[], help='The hidden dimensions of encoder')
    parser.add_argument('--enc_out_dim', type=int, default=1536, help='The output dimension of encoder')
    parser.add_argument('--enc_drop', type=float, default=0., help='The dropout rate of encoder')
    parser.add_argument('--enc_use_bn', type=bool, default=True, help='The flag of using batch normalization for encoder')
    parser.add_argument('--enc_act', type=str, default='prelu', help='The activation function for encoder')
    parser.add_argument('--enc_norm', type=bool, default=True, help='The flag of using normalization for encoder')
    # Loss settings
    parser.add_argument('--reg_const', type=float, default=0.1, help='The consistency regularization for proxy loss')
    parser.add_argument('--neigh_radius', type=float, default=0.5, help='The radius of neighbors for proxy update')
    parser.add_argument('--entropy_const', type=float, default=1000, help='The temperature for proxy loss')
    parser.add_argument('--update_ratio', type=float, default=0., help='The ratio of updating proxy')
    # Optimization settings
    parser.add_argument('--gpu', type=int, default=0, help='GPU index.')
    parser.add_argument('--seed', type=int, default=2024, help='Random seed.')
    parser.add_argument('--epochs', type=int, default=500, help='The training epochs')
    parser.add_argument('--min_delta', type=float, default=1e-2, help='The minimum loss decrease for early stopping')
    parser.add_argument('--patience', type=int, default=15, help='The patience for early stopping')
    parser.add_argument('--lr', type=float, default=0.0004, help='The learning rate for the model')
    parser.add_argument('--wd', type=float, default=5e-5, help='The weight decay of training')
    parser.add_argument('--opt_scheduler', type=str, default='step', help='lr schedular mode for optimizer (None or "step")')
    parser.add_argument('--opt_decay_step', type=int, default=100, help='lr decay step threshold for optimizer')
    parser.add_argument('--opt_decay_rate', type=float, default=0.96, help='lr decay rate for optimizer')
    # Other settings
    parser.add_argument('--is_pretrained', type=int, default=1, help='1 to pretrain the model and 0 otherwise')
    parser.add_argument('--model_dir', type=str, default='./pretrain/', help='Directory to save the pretrained model')
    args = parser.parse_args()
    return args


def main():
    """Load arguments"""
    args = argument()
    device = torch.device(f'cuda:{args.gpu}' if torch.cuda.is_available() else 'cpu')
    
    """Set random seeds for reproducibility"""
    seed = args.seed
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
    
    """Load the dataset"""
    print(f"Loading {args.dataset} dataset...")
    data_pyg = load_data(args.dataset, args.is2undirected)
    labels = data_pyg.y.view(-1).to(device)
    feat_dim, num_classes = data_pyg.x.shape[1], get_class_num(labels)
    print(f'> Data Basic Info: ' + 
          f'#Nodes={data_pyg.num_nodes}, #Edges={data_pyg.num_edges}, ' + 
          f'#Clusters={num_classes}, #FeatDim={feat_dim}')

    """Model Definition and Initialization"""
    # Define the model
    print('Initializing the model...')
    model = DPNet(args, feat_dim, num_classes).to(device)
    trainable_params = list(model.parameters())
    sched, opt = get_optimizer("adamw", trainable_params,
                               lr=args.lr, weight_decay=args.wd, 
                               opt_scheduler=args.opt_scheduler, 
                               decay_step=args.opt_decay_step,
                               decay_rate=args.opt_decay_rate)
    print('Model initialized.')
    # Load the pre-trained encoder if needed
    if args.is_pretrained:
        model.load_state_dict(torch.load(
            os.path.join(args.model_dir, f"model_{args.dataset}.pt")
        ))
    # Dual Proxies Initialization
    print('Initializing the dual proxies...')
    with torch.no_grad():
        emb_init = model.get_embeddings(data_pyg.to(device)).detach()
    inter_proxy, exter_proxy, pseudo_labels = init_proxies(args.dataset, emb_init, num_classes, 
                                                           args.neigh_radius, device)
    model.inter_proxy.data = inter_proxy
    print('Initialization completed.')
    
    """Training the model"""
    print('Training the model...')
    loss_list = []
    low_loss, counter = float('inf'), 1
    for epoch in tqdm(range(args.epochs), desc='Training'):
        model.train()
        opt.zero_grad()
        # Data augmentation
        aug_seed = random.randint(0, seed)
        data_pyg_v1 = random_aug(data_pyg, args.feat_mask_rate1, args.edge_mask_rate1, aug_seed)
        data_pyg_v2 = random_aug(data_pyg, args.feat_mask_rate2, args.edge_mask_rate2, aug_seed)
        # Forward pass
        loss, _, _ = model(data_pyg_v1.to(device), data_pyg_v2.to(device),
                                        exter_proxy, pseudo_labels)
        loss.backward()
        opt.step()
        if sched is not None:
            sched.step()
        loss_list.append(loss.item())
        smoothed_loss_list = exp_moving_average(loss_list, alpha=0.9)
        # print(f'Epoch {epoch+1}/{args.epochs}, Loss: {loss.item():.4f}, '
        #       f'Loss_DP: {loss_dp.item():.4f}, Loss_Reg: {loss_reg.item():.4f}')
        # Update the ECCs and pseudo labels
        with torch.no_grad():
            emb_v1 = model.get_embeddings(data_pyg_v1.to(device)).detach()
            emb_v2 = model.get_embeddings(data_pyg_v2.to(device)).detach()
            emb_v1 = F.normalize(emb_v1, p=2, dim=-1)
            emb_v2 = F.normalize(emb_v2, p=2, dim=-1)
            # sim_node2cen = cal_sim_feat2cen(emb, model.inter_proxy.data.detach())
            sim_node2cen_v1 = cal_sim_feat2cen(emb_v1, model.inter_proxy.data.detach())
            sim_node2cen_v2 = cal_sim_feat2cen(emb_v2, model.inter_proxy.data.detach())
            sim_node2cen = (sim_node2cen_v1 + sim_node2cen_v2) * 0.5
            pseudo_labels = update_pseudo_labels(sim_node2cen, model.inter_proxy.data.detach(),
                                                 pseudo_labels, args.entropy_const,
                                                 args.update_ratio)
            # update the ECCs
            emb = (emb_v1 + emb_v2) * 0.5
            exter_proxy = update_eccs(emb, model.inter_proxy.data.detach(), sim_node2cen,
                                      pseudo_labels, args.neigh_radius, mode='prob')
        # Early stopping
        if smoothed_loss_list[-1] >= smoothed_loss_list[0]:
            low_loss = smoothed_loss_list[0]
        elif smoothed_loss_list[-1] < low_loss - args.min_delta:
            low_loss = smoothed_loss_list[-1]
            counter = 0
        else:
            counter += 1
            if (counter > args.patience):
                print(f"Early stopping at epoch {epoch+1}.")
                break
    print('Training completed.')
    
    # Final evaluation
    print('Final evaluation...')
    model.eval()
    with torch.no_grad():
        emb_final = model.get_embeddings(data_pyg.to(device)).detach()
    emb_final = F.normalize(emb_final, p=2, dim=-1)
    sim_node2cen_final = cal_sim_feat2cen(emb_final, model.inter_proxy.data.detach())
    _ = eval_clustering_with_inter_proxy(
        sim_node2cen_final, model.inter_proxy.data.detach(),
        pseudo_labels, labels, args.entropy_const, args.update_ratio,
        use_reg=True
    )
    
if __name__ == '__main__':
    main()
