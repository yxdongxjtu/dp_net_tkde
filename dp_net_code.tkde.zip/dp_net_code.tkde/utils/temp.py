# -*- coding: utf-8 -*-
"""
Title:   Template for testing
Author:  Y. Dong
E-mail:  dyx_xjtu@163.com
Created: Apr 29, 2025

Description: 
"""

import socket


############################# Get Dataset Path ############################

# Define the dataset path mapping
DATASET_PATH_MAPPING_PYG = {
    '202.117.43.206': '/data/dyx/dataset',
    '10.181.8.126': '/data1/dyx/dataset',
    '10.181.8.127': '/data/dyx/dataset',
    '10.181.8.128': '/date/dyx/dataset',
}
DATASET_PATH_MAPPING_DGL = {
    '202.117.43.206': '/data/dyx/dataset_dgl',
    '10.181.8.126': '/data1/dyx/dataset_dgl',
    '10.181.8.127': '/data/dyx/dataset_dgl',
    '10.181.8.128': '/date/dyx/dataset_dgl',
}


def get_ip_address():
    """Get the IP address of the machine.
    Returns:
        str: The IP address of the machine.
    """
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            ip_address = s.getsockname()[0]
        return ip_address
    except Exception as e:
        print(f"Error getting IP address: {e}")
        return None


def get_dataset_path(data_source='pyg'):
    """Get the path to the dataset.
    Args:
        data_source (str, optional): The source of the dataset. Defaults to 'pyg'.
    Returns:
        str: The path to the dataset.
    """
    ip_address = get_ip_address()
    if data_source == 'pyg':
        # get dataset from PyG 
        if ip_address in DATASET_PATH_MAPPING_PYG:
            dataset_path = DATASET_PATH_MAPPING_PYG[ip_address]
        else:
            dataset_path = None
    elif data_source == 'dgl':
        # get dataset from DGL
        if ip_address in DATASET_PATH_MAPPING_DGL:
            dataset_path = DATASET_PATH_MAPPING_DGL[ip_address]
        else:
            dataset_path = None
    else:
        raise ValueError(f"Unknown data source: {data_source}")
    return dataset_path

