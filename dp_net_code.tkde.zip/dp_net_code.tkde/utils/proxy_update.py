# -*- coding: utf-8 -*-
"""
Title:   Update dual proxies
"""

import random

import torch
import torch.nn.functional as F
from scipy.stats import beta
from torch_scatter import scatter_add

from utils.data_process import get_class_num
from utils.model_helper import number_stability


def update_eccs(feat, iccs, sim_node2cen, pseudo_labels, neigh_radius=0.5, mode='prob'):
    """Update the ECCs based on the node embeddings and the ICCs.
    Args:
        feat (torch.Tensor): The node embeddings.
        iccs (torch.Tensor): The inter-cluster centers.
        sim_node2cen (torch.Tensor): The similarity scores between the node embeddings and the ICCs.
        pseudo_labels (torch.Tensor): The pseudo labels of the nodes.
        neigh_radius (float, optional): The radius of the neighborhood. Defaults to 0.5.
        mode (str, optional): The mode for updating the ECCs. Defaults to 'prob'.
        seed (int, optional): The random seed. Defaults to 42.
    Returns:
        torch.Tensor: The updated ECCs.
    """
    device = feat.device
    node_num, cluster_num = feat.size(0), iccs.size(0)
    eps = 1e-12
    # Convert the pseudo labels to torch.Tensor
    pseudo_labels = torch.as_tensor(pseudo_labels, dtype=torch.long, device=device)
    # Finding the nearest clusters for each cluster (by the given mode) -> shape: (cluster_num)
    nearest_neigh_clusters = find_nearest_clusters(iccs, sim_node2cen, mode=mode).to(device)
    # Creating a mask for the nodes in the neighborhood clusters
    node4nnc_mask = pseudo_labels[:, None] == nearest_neigh_clusters[None, :] # shape: (node_num, cluster_num)
    node4nnc_probs_mat = filter_nodes_in_neigh_cluster(sim_node2cen * node4nnc_mask, neigh_radius)
    node4nnc_idx = torch.where(node4nnc_probs_mat > eps)
    # Calculate the boundary representation b_lk: cluster l* w.r.t. cluster k
    node4nnc_probs = node4nnc_probs_mat[node4nnc_idx]
    node4ncc_probs_norm = normalize_probs_by_idx(node4nnc_probs, node4nnc_idx[1])
    b_lk = scatter_add(
        feat[node4nnc_idx[0]] * node4ncc_probs_norm[:, None], 
        node4nnc_idx[1], 
        dim=0
    )
    # Calculate the boundary representation b_kl: cluster k w.r.t. cluster l*
    node2ncc = nearest_neigh_clusters[pseudo_labels.tolist()]
    node2ncc_probs = sim_node2cen[range(node_num), node2ncc]    
    node2ncc_probs_mat = F.one_hot(pseudo_labels.long(), cluster_num).float().to(device)
    node2ncc_probs_expand = node2ncc_probs.unsqueeze(1).expand(-1, cluster_num)
    node2ncc_probs_mat = node2ncc_probs_mat * node2ncc_probs_expand
    node2ncc_probs_mat = filter_nodes_in_neigh_cluster(node2ncc_probs_mat, neigh_radius)
    node2ncc_idx = torch.where(node2ncc_probs_mat > eps)
    node2ncc_probs = node2ncc_probs_mat[node2ncc_idx]
    node2ncc_probs_norm = normalize_probs_by_idx(node2ncc_probs, node2ncc_idx[1])
    b_kl = scatter_add(
        feat[node2ncc_idx[0]] * node2ncc_probs_norm[:, None], 
        node2ncc_idx[1], 
        dim=0
    )
    # Update the ECCs    
    alpha = beta.rvs(10, 10)
    alpha = max(alpha, 1 - alpha)
    eccs = alpha * b_lk + (1 - alpha) * b_kl
    eccs = F.normalize(eccs, p=2, dim=-1)
    return eccs


def find_nearest_clusters(iccs, sim_node2cen, mode='prob'):
    """Finds the nearest clusters based on the given mode.
    Args:
        iccs (torch.Tensor): The inter-cluster centers.
        sim_node2cen (torch.Tensor): The similarity matrix between features and cluster centers.
        mode (str): The mode to determine the nearest clusters. Can be either 'feat' or 'prob'.
    Returns:
        nearest_cluster (torch.Tensor): The tensor containing the indices of the nearest clusters.
    """
    if mode == 'feat':
        # Find the nearest clusters based on the feature similarity of iccs
        dist_iccs2iccs = torch.cdist(iccs, iccs, p=2)
        dist_iccs2iccs = dist_iccs2iccs.fill_diagonal_(float('inf'))
        nearest_cluster = torch.argmin(dist_iccs2iccs, dim=-1)
    elif mode == 'prob':
        # Find the nearest clusters based on the cluster prediction distribution distance (JSD)
        jsd_pred2pred = cal_jsd_matrix(sim_node2cen)
        jsd_pred2pred = jsd_pred2pred.fill_diagonal_(float('inf'))
        nearest_cluster = torch.argmin(jsd_pred2pred, dim=-1)
    else:
        raise NotImplementedError(f"Invalid mode: {mode}")
    return nearest_cluster


def cal_jsd_matrix(prob_mat):
    """Calculates the Jensen-Shannon Divergence (JSD) matrix based on the given probability matrix.
    Args:
        prob_mat (torch.Tensor): The probability matrix of shape (n, K), where n is the number of samples and K is the number of clusters.
    Returns:
        torch.Tensor: The JSD matrix of shape (K, K), where K is the number of clusters.
    """
    # Adding a small epsilon for numerical stability
    eps = 1e-12
    prob_mat = prob_mat.clamp(min=eps)
    # Compute pairwise JSD matrix
    cluster_num = prob_mat.size(1)
    jsd_mat = torch.zeros((cluster_num, cluster_num), device=prob_mat.device)
    for k in range(cluster_num):
        p_k = prob_mat[:, k].unsqueeze(1)
        for l in range(k+1, cluster_num):
            # Compute JSD between cluster k and l
            p_l = prob_mat[:, l].unsqueeze(1)
            p_m = 0.5 * (p_k + p_l)
            kld_pk_pm = F.kl_div(p_k.log(), p_m, reduction='batchmean')
            kld_pl_pm = F.kl_div(p_l.log(), p_m, reduction='batchmean')
            jsd_val = 0.5 * (kld_pk_pm + kld_pl_pm)
            # Fill the JSD matrix symmetrically
            jsd_mat[k, l] = jsd_val
            jsd_mat[l, k] = jsd_val
    return jsd_mat


def filter_nodes_in_neigh_cluster(sim_node2cen, top_percent=0.5, eps=1e-12):
    """Filter the nodes in the neighborhood clusters.
    Args:
        sim_node2cen (torch.Tensor): The similarity matrix between features and cluster centers.
        top_percent (float, optional): The percentage of the top nodes to keep. Defaults to 0.5.
        eps (float, optional): A small epsilon value. Defaults to 1e-12.
    Returns:
        torch.Tensor: The filtered similarity matrix.
    """
    if not 0 < top_percent < 1:
        raise ValueError(f"Invalid top_percent value: {top_percent} (should be in (0, 1))")
    # Calculate the threshold for each cluster in parallel
    valid_mask = sim_node2cen > eps
    masked_sim = sim_node2cen.masked_fill(~valid_mask, float('nan'))
    thresholds = torch.nanquantile(masked_sim, top_percent, dim=0)
    # Apply thresholds using broadcasting
    return sim_node2cen * (sim_node2cen >= thresholds.unsqueeze(0))


def normalize_probs_by_idx(probs, cluster_idx):
    """Normalize the probabilities by dividing each probability by the sum of probabilities
    belonging to the same cluster index.
    Args:
        probs (torch.Tensor): Tensor containing the probabilities.
        cluster_idx (torch.Tensor): Tensor containing the cluster indices.
    Returns:
        torch.Tensor: Tensor containing the normalized probabilities.
    """
    probs_sum = scatter_add(probs, cluster_idx, dim=0)
    normalized_probs = probs / (probs_sum[cluster_idx] + 1e-12)
    return normalized_probs


def update_pseudo_labels(sim_node2cen, iccs, pseudo_labels, alpha=100, update_ratio=0.):
    """Updates pseudo labels for nodes based on similarity to cluster centers with entropy regularization.
    Args:
        sim_node2cen (torch.Tensor): Similarity matrix between nodes and cluster centers with shape (n_nodes, n_clusters)
        iccs (torch.Tensor): Initial cluster centers tensor
        pseudo_labels (torch.Tensor): Current pseudo labels for nodes with shape (n_nodes,)
        alpha (float, optional): Weight of entropy regularization term. Defaults to 100
        update_ratio (float, optional): Ratio of labels to update. Between 0 and 1. Defaults to 0.5
    Returns:
        torch.Tensor: Updated pseudo labels for nodes with shape (n_nodes,)
    """
    device = iccs.device
    eps = 1e-12
    node_num, cluster_num = len(pseudo_labels), iccs.size(0)
    pseudo_labels = torch.as_tensor(pseudo_labels, dtype=torch.long, device=device)
    # Calculate the entropy regularization term for each cluster
    pseudo_labels_onehot = F.one_hot(pseudo_labels, cluster_num).float().to(device)
    cluster_count = pseudo_labels_onehot.sum(dim=0)
    cluster_prob_pre = (cluster_count.unsqueeze(0) - pseudo_labels_onehot) / node_num
    # Calculate the entropy regularization term for each node
    log_cluster_prob_pre = torch.log(cluster_prob_pre + eps)
    entropy_pre = cluster_prob_pre * log_cluster_prob_pre
    entropy_pre_sum = entropy_pre.sum(dim=1, keepdim=True)
    # Update the pseudo labels
    cluster_prob_new = cluster_prob_pre + (1. / node_num)
    entropy = (cluster_prob_new * torch.log(cluster_prob_new + eps) + 
               entropy_pre_sum - entropy_pre)
    # entropy = number_stability(entropy)
    entropy = F.normalize(entropy, p=2, dim=-1)
    scores = -torch.log(sim_node2cen + eps) + alpha * entropy
    updated_labels = torch.argmin(scores, dim=-1) 
    # Ensure cluster number consistency
    while True:
        updated_labels = update_labels_with_threshold(
            updated_labels, pseudo_labels, sim_node2cen, update_ratio
        )
        if get_class_num(updated_labels) == cluster_num:
            break
        update_ratio = min(update_ratio + 0.1, 1.0)
    return updated_labels


def update_labels_with_threshold(updated_labels, pseudo_labels, sim_node2cen, update_ratio=0.5):
    """Update the pseudo labels based on the given features and cluster centers.
    Args:
        updated_labels (torch.Tensor): The updated labels.
        pseudo_labels (torch.Tensor): The pseudo labels.
        sim_node2cen (torch.Tensor): The similarity between features and cluster centers.
        update_ratio (float, optional): The ratio of labels to update. Defaults to 0.5.
    Returns:
        torch.Tensor: The updated labels.
    """
    # Get label probabilities for the updated labels in sim_node2cen
    changed_label_idx = torch.where(updated_labels != pseudo_labels)[0]
    if len(changed_label_idx) == 0:
        return updated_labels
    updated_lable_prob = sim_node2cen[changed_label_idx, updated_labels[changed_label_idx]]
    # Only update the labels with a higher probability (top (1-update_ratio) percent)
    threshold = torch.quantile(updated_lable_prob, update_ratio)
    updated_labels[changed_label_idx] = torch.where(
        updated_lable_prob > threshold, 
        updated_labels[changed_label_idx], 
        pseudo_labels[changed_label_idx]
    )
    return updated_labels
