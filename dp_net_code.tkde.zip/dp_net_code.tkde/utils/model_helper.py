# -*- coding: utf-8 -*-
"""
Title:   Helper Functions for Model Building
"""

import torch
import torch.optim as optim
import torch.nn.functional as F
import torch_geometric.nn as pyg_nn
import numpy as np


def get_activation(act):
    """Get activation function.
    Args:
        act (str): The activation function to retrieve.
    Returns:
        torch.nn.Module: The requested activation function.
    """
    if act == 'relu':
        return torch.nn.ReLU(inplace=True)
    elif act == 'prelu':
        return torch.nn.PReLU()
    elif act == 'tanh':
        return torch.nn.Tanh()
    elif act == 'sigmoid':
        return torch.nn.Sigmoid()
    elif act == 'softmax':
        return torch.nn.Softmax()
    elif (act is None) or (act == 'none'):
        return torch.nn.Identity()
    else:
        raise NotImplementedError


def get_optimizer(opt, params, lr, weight_decay, opt_scheduler=None, 
                  decay_step=0, decay_rate=0.):
    """Build optimizer for the given model.
    Args:
        opt (str): The optimizer type. Possible values are 'adam', 'sgd', or 'adamw'.
        params (iterable): The parameters to optimize.
        lr (float): The learning rate.
        weight_decay (float): The weight decay.
        opt_scheduler (str, optional): The optimizer scheduler type. Possible values are 'step' or None.
        decay_step (int, optional): The step size for the scheduler. Default is 0.
        decay_rate (float, optional): The decay rate for the scheduler. Default is 0.
    Returns:
        tuple: A tuple containing the optimizer and the scheduler (if opt_scheduler is provided), or just the optimizer.
    """
    params_fn = filter(lambda p: p.requires_grad, list(params))
    if opt == 'adam':
        optimizer = optim.Adam(params_fn, lr=lr, weight_decay=weight_decay)
    elif opt == 'sgd':
        optimizer = optim.SGD(params_fn, lr=lr, weight_decay=weight_decay)
    elif opt == 'adamw':
        optimizer = optim.AdamW(params_fn, lr=lr, weight_decay=weight_decay)
    if not opt_scheduler:
        return None, optimizer
    elif opt_scheduler == 'step':
        scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=decay_step, 
                                              gamma=decay_rate)
        return scheduler, optimizer


def number_stability(mat_th):
    """Applies number stability to the input matrix.
    Args:
        mat_th (torch.Tensor): Input matrix.
    Returns:
        torch.Tensor: Matrix with number stability applied.
    """
    logits_max, _ = torch.max(mat_th, dim=-1, keepdim=True)
    logits = mat_th - logits_max.detach()
    return torch.exp(logits)


def loss_fn(x, y):
    """Calculates the loss between two vectors x and y.
    Args:
        x (torch.Tensor): The first input tensor.
        y (torch.Tensor): The second input tensor.
    Returns:
        torch.Tensor: The calculated loss.
    """
    # Normalize the input tensors
    x = F.normalize(x, dim=-1, p=2)
    y = F.normalize(y, dim=-1, p=2)
    # Calculate the loss
    return 2 - 2 * (x * y).sum(dim=-1).mean()


def get_graph_conv(dim_in, dim_out, model_type):
    """Build enc model for each layer.
    Args:
        dim_in (int): The input dimension of the graph convolution layer.
        dim_out (int): The output dimension of the graph convolution layer.
        model_type (str): The type of the graph convolution model.
    Returns:
        pyg_nn.Conv: The graph convolution layer based on the specified model type.
    """
    if model_type == "GCN":
        return pyg_nn.GCNConv(dim_in, dim_out)
    elif model_type == "GraphSage":
        return pyg_nn.SAGEConv(dim_in, dim_out, aggr='add')
    elif model_type == "GAT":
        return pyg_nn.GATConv(dim_in, dim_out)  
    elif model_type == 'GIN':
        return pyg_nn.GINConv(dim_in, dim_out)
    else:
        raise NotImplementedError


def cal_sim_feat2cen(feat, cluster_cens, scaling_factor=1.0):
    """Calculate the similarity between each node and the cluster centers.
    Args:
        feat (torch.Tensor): The features of the nodes.
        cluster_cens (torch.Tensor): The cluster centers.
        scaling_factor (float, optional): The scaling factor. Defaults to 1.0.
    Returns:
        torch.Tensor: The distance between each node and the cluster centers.
    """
    # Euclidean distance-based similarity kernel
    sim_feat2cen = 1. / (1. + torch.cdist(feat, cluster_cens, p=2) ** 2 / scaling_factor + 1e-6)
    sim_feat2cen.pow_(scaling_factor + 1.) # Gaussian kernel
    sim_feat2cen.div_(torch.sum(sim_feat2cen, dim=1).unsqueeze(1) + 1e-6) # normalization
    return sim_feat2cen


def moving_average(loss_list, window_size=10):
    """Calculate the moving average of the given loss list.
    Args:
        loss_list (list): The list of losses.
        window_size (int, optional): The window size for the moving average. Defaults to 5.
    Returns:
        list: The moving average of the loss list.
    """
    if len(loss_list) < window_size:
        return loss_list
    loss_list_np = np.array(loss_list)
    weights = np.repeat(1.0, window_size) / window_size
    smoothed_loss = np.convolve(loss_list_np, weights, 'valid')
    return smoothed_loss.tolist()


def exp_moving_average(loss_list, alpha=0.95):
    """Calculate the exponential moving average of the given loss list.
    Args:
        loss_list (list): The list of losses.
        alpha (float, optional): The alpha value for the moving average. Defaults to 0.9.
    Returns:
        list: The exponential moving average of the loss list.
    """
    ema = [loss_list[0]]
    for i in range(1, len(loss_list)):
        ema.append(alpha * ema[-1] + (1 - alpha) * loss_list[i])
    return ema
