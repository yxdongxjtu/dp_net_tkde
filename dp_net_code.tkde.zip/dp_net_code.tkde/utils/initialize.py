# -*- coding: utf-8 -*-
"""
Title:   Initialize the model
"""

import logging

import torch
import torch.nn.functional as F
from torch_scatter import scatter_add

from utils.evaluate import perform_kmeans
from utils.model_helper import cal_sim_feat2cen
from utils.proxy_update import update_eccs


def init_proxies(dataset, feat, cluster_num, neigh_radius, device): 
    """Initialize dual proxies for each cluster.
    Args:
        dataset (str): The name of the dataset.
        feat (torch.Tensor): The node embeddings.
        cluster_num (int): The number of clusters.
        device (torch.device): The device to perform computations on.
    Returns:
        tuple: A tuple containing ICCs and ECCs.
    """
    feat = F.normalize(feat, p=2, dim=-1).to(device)
    logging.info(f'Initializing proxies for the dataset {dataset}...')
    # Perform the k-means clustering on the node embeddings
    pseudo_labels, cluster_cens = perform_kmeans(feat.cpu().numpy(), cluster_num)
    # Initialize the ICCs
    sim_node2cen = cal_sim_feat2cen(feat, cluster_cens.to(device))
    iccs = cal_iccs(sim_node2cen, feat, mode="avg")
    # Initialize the ECCs
    eccs = update_eccs(feat, iccs, sim_node2cen, pseudo_labels, neigh_radius, mode='prob')
    # eccs = F.normalize(eccs, p=2, dim=-1)
    return iccs, eccs, pseudo_labels
    

def cal_iccs(sim_node2cen, feat, mode="avg"):
    """Calculate the inter-cluster centers (average or weighted).
    Args:
        sim_node2cen (torch.Tensor): Tensor containing the similarity scores between features and cluster centers.
        feat (torch.Tensor): Tensor containing the features.
        mode (str, optional): Mode for calculating the inter-cluster centers. Defaults to 'avg'.
    Returns:
        torch.Tensor: Tensor containing the inter-cluster centers.
    """
    max_prob, pseudo_labels = torch.max(sim_node2cen, dim=1)
    if mode == "avg": 
        # Calculate the average of the features in each cluster
        iccs = scatter_add(feat, pseudo_labels, dim=0)
    elif mode == "weighted":
        # Calculate the weighted average of the features in each cluster
        max_prob_sum = scatter_add(max_prob, pseudo_labels, dim=0)
        max_prob_weighted = max_prob / (max_prob_sum[pseudo_labels] + 1e-6)
        iccs = scatter_add(feat * max_prob_weighted.unsqueeze(-1), pseudo_labels, dim=0)
    else:
        raise NotImplementedError(f"Unsupported mode: {mode}")
    iccs = F.normalize(iccs, p=2, dim=-1)
    return iccs
