# -*- coding: utf-8 -*-
"""
Title:   Data Loading and Preprocessing Utilities
"""

import os
import copy
import random

import torch
import numpy as np
import torch.nn.functional as F
from torch_geometric.datasets import Planetoid, Amazon, Reddit
from torch_geometric.utils import add_self_loops, remove_self_loops, to_undirected
from ogb.nodeproppred import PygNodePropPredDataset

#TODO: to delete the following lines
from utils.temp import get_dataset_path


# Dataset Info
DATA_CLASS_DICT = {
    'cora': Planetoid,
    'citeseer': Planetoid,
    "Computers": Amazon,
    "Photo": Amazon,
    'reddit': Reddit,
}


def load_data(dataset, is2undirected=False):
    """Load graph dataset.
    Args:
        dataset (str): The name of the dataset to load.
        is2undirected (bool, optional): Whether to convert the graph to undirected. Defaults to False.
    Returns:
        data_pyg (torch_geometric.data.Data): The PyG dataset.
    """
    data_pyg = download_data(dataset)
    # Add self-loops and convert to undirected graph
    data_pyg.edge_index = add_self_loops(remove_self_loops(data_pyg.edge_index)[0])[0]
    print(f'> Added self-loops to the graph.')
    if is2undirected:
        original_edge_num = data_pyg.edge_index.size(1)
        data_pyg.edge_index = to_undirected(data_pyg.edge_index)
        print(f'> Converted the graph to undirected. ' + 
              f'(From {original_edge_num} to {data_pyg.edge_index.size(1)} edges)')
    # Normalize the node features
    data_pyg = normalize_node_features(data_pyg)
    return data_pyg


def download_data(dataset: str):
    """Download the graph dataset.
    Args:
        dataset (str): The name of the dataset to download.
    Returns:
        data_pyg (torch_geometric.data.Data): The PyG dataset.
    """
    #TODO: 
    data_path = f'./data/{dataset}'
    data_path = get_dataset_path(data_source='pyg')
    # Load the dataset
    if dataset in ['cora', 'citeseer', 'pubmed', 'Computers', 'Photo', 'reddit']:
        # Load the dataset from PyG datasets 
        data_class = DATA_CLASS_DICT[dataset]
        data_path = os.path.join(data_path, dataset)
        data_pyg = data_class(data_path, f'{dataset}').data
        return data_pyg
    elif dataset in ['ogbn-arxiv', 'ogbn-products', 'ogbn-papers100M']:
        # Load the dataset from OGB datasets 
        data = PygNodePropPredDataset(name=dataset, root=data_path)
        data_pyg = data[0]
        return data_pyg
    else:
        # Raise an error for invalid dataset
        raise ValueError(f"Invalid dataset: {dataset}.")
    

def normalize_node_features(data_pyg):
    """Normalize the node features in the given PyG data object.
    Args:
        data_pyg (torch_geometric.data.Data): The PyG data object containing node features.
    Returns:
        torch_geometric.data.Data: The PyG data object with normalized node features.
    """
    if data_pyg.x is not None:
        data_pyg.x = F.normalize(data_pyg.x, p=2, dim=1)
        print(f'> Node features normalized.')
    return data_pyg


def get_class_num(labels):
    """Get the number of classes in the dataset.
    Args:
        dataset (str): The name of the dataset.
        labels (torch.Tensor): The node labels.
    Returns:
        int: The number of classes in the dataset.
    """
    if isinstance(labels, list):
        labels = torch.tensor(labels)
    elif isinstance(labels, np.ndarray):
        labels = torch.from_numpy(labels)
    if torch.isnan(labels).sum() == 0:
        return len(torch.unique(labels))
    else:
        labeled_mask = ~torch.isnan(labels)
        return len(torch.unique(labels[labeled_mask]))


########################## Data Augmentation ##########################

def shuffle_feature(x):
    """Shuffle the feature values.
    Args:
        x (numpy.ndarray): The input feature array.
    Returns:
        numpy.ndarray: The shuffled feature array.
    """
    shuffled_idx = np.random.permutation(x.shape[0])
    aug_x = copy.deepcopy(x)[shuffled_idx, :]
    return aug_x


def random_aug(data_pyg, feat_mask_prob, edge_mask_prob, seed=2024):
    """Random graph data augmentation.
    Args:
        data_pyg (torch_geometric.data.Data): The input graph data.
        feat_mask_prob (float): The probability of masking a feature.
        edge_mask_prob (float): The probability of dropping an edge.
    Returns:
        torch_geometric.data.Data: The augmented graph data.
    """
    if feat_mask_prob == 0 and edge_mask_prob == 0:
        return data_pyg
    # Set the random seed
    random.seed(seed)
    seed = random.randint(0, seed)
    # Randomly drop features
    x_new = drop_feature(data_pyg.x, feat_mask_prob)
    # Randomly drop edges
    edge_index_new = drop_edge(data_pyg.edge_index, edge_mask_prob, 
                               force_undirected=False)
    # Create the new data object
    data_new = copy.deepcopy(data_pyg)
    data_new.x = x_new
    data_new.edge_index = edge_index_new
    return data_new
    

def drop_feature(x, drop_prob):
    """Drop feature values randomly.
    Args:
        x (torch.Tensor): Input tensor of shape (batch_size, num_features).
        drop_prob (float): Probability of dropping a feature value.
    Returns:
        torch.Tensor: Tensor with randomly dropped feature values.
    """
    # check the drop probability
    if drop_prob == 0.:
        return copy.deepcopy(x)
    # mask the features
    drop_mask = torch.rand(x.size(1), device=x.device) < drop_prob
    x = copy.deepcopy(x)
    x[:, drop_mask] = 0.
    return x


def drop_edge(edge_index, drop_prob, force_undirected=False):
    """Drop edges randomly.
    Args:
        edge_index (torch.Tensor): Input edge tensor of shape (2, num_edges).
        drop_prob (float): Probability of dropping an edge.
    Returns:
        torch.Tensor: Edge tensor with randomly dropped edges.
    """
    # mask the edges
    row, col = edge_index
    drop_mask = torch.rand(row.size(0), device=edge_index.device) >= drop_prob
    if force_undirected:
        drop_mask[row > col] = False
    row, col = row[drop_mask], col[drop_mask]
    if force_undirected:
        edge_index = torch.stack([torch.cat([row, col], dim=0),
                                  torch.cat([col, row], dim=0)], dim=0)
    else:
        edge_index = torch.stack([row, col], dim=0)
    return edge_index
