# -*- coding: utf-8 -*-
"""
Title:   Result Evaluation Functions
"""

import torch
import torch.nn.functional as F
import numpy as np
from sklearn.cluster import KMeans, MiniBatchKMeans
from sklearn.metrics import normalized_mutual_info_score, adjusted_rand_score, \
                            accuracy_score, f1_score
from munkres import Munkres

from utils.data_process import get_class_num
from utils.proxy_update import update_pseudo_labels


def perform_kmeans(feat, cluster_num, seed=1234):
    """Perform the k-means clustering.
    Args:
        feat (array-like): The input features to be clustered.
        cluster_num (int): The number of clusters to create.
        seed (int, optional): The random seed for reproducibility. Defaults to 1234.
    Returns:
        tuple: A tuple containing the pseudo labels assigned to each data point and the cluster centers.
    """
    #TODO: When release, comment the following line (for reproducibility)
    # np.random.seed(seed)
    seed = np.random.randint(seed)
    # Perform the k-means clustering (for sklearn > 1.3.2, set init='auto')
    kmeans = KMeans(n_clusters=cluster_num, init='k-means++', random_state=seed).fit(feat)
    pesudo_labels = kmeans.labels_
    cluster_cens = torch.from_numpy(kmeans.cluster_centers_)#.to(torch.float)
    return pesudo_labels, cluster_cens


def perform_mini_batch_kmeans(feat, cluster_num, batch_size=8192, seed=1234):
    """Perform the mini-batch k-means clustering.
    Args:
        feat (array-like): The input features to be clustered.
        cluster_num (int): The number of clusters to create.
        seed (int, optional): The random seed for reproducibility. Defaults to 1234.
    Returns:
        tuple: A tuple containing the pseudo labels assigned to each data point and the cluster centers.
    """
    np.random.seed(seed)
    seed = np.random.randint(seed)
    # Perform the mini-batch k-means clustering (for sklearn version >= 1.3.2, set n_init='auto')
    kmeans = MiniBatchKMeans(n_clusters=cluster_num, batch_size=batch_size, 
                             init='k-means++', random_state=seed).fit(feat)
    pseudo_labels = kmeans.labels_
    cluster_cens = torch.from_numpy(kmeans.cluster_centers_).float()
    return pseudo_labels, cluster_cens


def cal_clustering_metrics(labels, pseudo_labels):
    """Calculate the clustering metrics.
    Args:
        labels (array-like): True labels of the data.
        pseudo_labels (array-like): Predicted labels of the data.
    Returns:
        dict: A dictionary containing the clustering metrics.
            - 'acc': Accuracy score.
            - 'nmi': Normalized Mutual Information score.
            - 'ari': Adjusted Rand Index score.
            - 'f1_macro': Macro-averaged F1 score.
    """
    # Convert the labels to numpy array
    if isinstance(labels, torch.Tensor):
        labels = labels.cpu().numpy()
    if isinstance(pseudo_labels, torch.Tensor):
        pseudo_labels = pseudo_labels.cpu().numpy()
    # Check the NaN values in the labels (for ogbn-papers100M)
    if np.isnan(labels).sum() > 0:
        labeled_mask = ~np.isnan(labels)
        labels = labels[labeled_mask]
        pseudo_labels = pseudo_labels[labeled_mask]
    # Get the number of clusters
    cluster_num = get_class_num(labels)
    pseudo_cluster_num = get_class_num(pseudo_labels)
    # Calculate the clustering metrics
    nmi = normalized_mutual_info_score(labels, pseudo_labels)
    ari = adjusted_rand_score(labels, pseudo_labels)
    if cluster_num == pseudo_cluster_num:
        # Align the predicted labels with the ground-truth labels
        pseudo_labels = label_alignment(labels, pseudo_labels)
        acc = accuracy_score(labels, pseudo_labels)
        f1_macro = f1_score(labels, pseudo_labels, average='macro')
    else:
        # Log the cluster number mismatch and set the metrics to 0
        print(f'Cluster number mismatch: {cluster_num} vs. {pseudo_cluster_num}')
        acc = 0.0
        f1_macro = 0.0
    # Log the clustering results
    print(f'> Clustering Results: ACC={acc:.4f}, NMI={nmi:.4f}, ARI={ari:.4f}, F1_macro={f1_macro:.4f}')
    res_dict = {
        'acc': acc,
        'nmi': nmi,
        'ari': ari,
        'f1_macro': f1_macro
    }
    return res_dict


def label_alignment(true_labels, pred_labels):
    """Aligns two clustering results by using the Hungarian algorithm.
    Args:
        pred_labels (Tensor): The predicted labels.
        true_labels (Tensor): The ground-truth labels.
    Returns:
        numpy.ndarray: The aligned clustering predicted labels.
    """
    # Check if the number of the two labelings is the same
    l1, l2 = list(set(true_labels)), list(set(pred_labels))
    if len(l1) != len(l2):
        raise ValueError(f'Class Not equal ({len(l1)} != {len(l2)}), Error!!!!')
    # Build a cost matrix for the Hungarian algorithm
    num_class = len(l1)
    cost = np.zeros((num_class, num_class), dtype=int)
    for i, c1 in enumerate(l1):
        mps = [i1 for i1, e1 in enumerate(true_labels) if e1 == c1]
        for j, c2 in enumerate(l2):
            mps_d = [i1 for i1 in mps if pred_labels[i1] == c2]
            cost[i][j] = len(mps_d)
    # match two clustering results by Munkres algorithm (i.e., Hungarian algorithm)
    m = Munkres()
    cost = cost.__neg__().tolist()
    indexes = m.compute(cost)
    # get the match results
    new_predict = np.zeros(len(pred_labels), dtype=int)
    for i, c in enumerate(l1):
        # correponding label in l2:
        c2 = l2[indexes[i][1]]
        # ai is the index with label==c2 in the pred_label list
        ai = [ind for ind, elm in enumerate(pred_labels) if elm == c2]
        new_predict[ai] = c
    return new_predict


def eval_clustering_with_inter_proxy(sim_feat2cen, inter_proxy, pseudo_labels, labels, 
                                     alpha, update_ratio, use_reg=True):
    """Evaluate the clustering performance with the inter-cluster proxies.
    Args:
        sim_feat2cen (torch.Tensor): The similarity scores between features and cluster centers.
        inter_proxy (torch.Tensor): The inter-cluster centers.
        labels (torch.Tensor): The ground truth labels.
    Returns:
        dict: A dictionary containing the clustering metrics.
    """
    if use_reg:
        final_labels = update_pseudo_labels(sim_feat2cen, inter_proxy, pseudo_labels, 
                                            alpha, update_ratio)
    else:
        _, final_labels = torch.max(sim_feat2cen, dim=-1)
    # Calculate the clustering metrics
    res_dict = cal_clustering_metrics(labels, final_labels)
    return res_dict


def eval_clustering(dataset, feat, labels):
    """Evaluate the clustering performance.
    Args:
        dataset (str): The name of the dataset.
        feat (torch.Tensor): The input features.
        labels (torch.Tensor): The ground truth labels.
    Returns:
        dict: A dictionary containing the clustering metrics.
    """
    labels = labels.cpu()
    cluster_num = get_class_num(labels)
    feat = F.normalize(feat, p=2, dim=1).cpu().detach()
    # feat = feat.cpu().detach()
    # Perform the k-means clustering
    if dataset in ['ogbn-arxiv', 'ogbn-products', 'ogbn-papers100M', 'Reddit']:
        batch_size = 16384 if dataset == 'ogbn-papers100M' else 8192
        pseudo_labels, _ = perform_mini_batch_kmeans(feat, cluster_num, batch_size=batch_size)
    else: 
        pseudo_labels, _ = perform_kmeans(feat, cluster_num)
    # Calculate the clustering metrics
    res_dict = cal_clustering_metrics(labels, pseudo_labels)
    return res_dict

