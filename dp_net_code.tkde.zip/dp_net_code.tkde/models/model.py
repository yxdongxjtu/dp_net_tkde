# -*- coding: utf-8 -*-
"""
Title:   DP-Net Model
"""

import torch
import torch.nn as nn
import torch.nn.functional as F

from models.encoder import EncGNN
from utils.data_process import shuffle_feature
from utils.model_helper import loss_fn


class DPNet(nn.Module):
    """Dual-Proxy Graph Clustering Framework"""
    def __init__(self, 
                 args, 
                 in_dim: int, 
                 cluster_num: int):
        super().__init__()
        # Parameters
        self.cluster_num = cluster_num
        self.reg_const = args.reg_const
        # Build the model
        self.inter_proxy = nn.Parameter(torch.zeros(cluster_num, args.enc_out_dim))
        self.encoder = EncGNN(in_dim, args.enc_hids_dim, args.enc_out_dim, 
                              args.enc_type, args.enc_drop, args.enc_use_bn,
                              args.enc_act, args.enc_norm)
        self.proj = nn.Sequential(
            nn.Linear(args.enc_out_dim, args.enc_out_dim),
        )
        self._init_weights(self)
        # define the loss function
        self.kl_loss = nn.KLDivLoss(reduction='batchmean')
        self.bce_loss = nn.BCEWithLogitsLoss()

    @staticmethod
    def _init_weights(self):
        """Initialize weights."""
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_normal_(m.weight.data)
                if m.bias is not None:
                    nn.init.zeros_(m.bias.data)

    def get_embeddings(self, data_pyg):
        """Get the node embeddings."""
        return self.proj(self.encoder(data_pyg.x, data_pyg.edge_index))

    def cal_loss_pretrain(self, data_pyg):
        """Calculate the loss for pretraining the encoder."""
        # Augmentation for the input data
        node_num = data_pyg.x.size(0)
        x_aug = data_pyg.x.clone()
        x_shuffle = shuffle_feature(x_aug)
        # Node embedding
        emb_aug = self.encoder(x_aug, data_pyg.edge_index)
        emb_shuffle = self.encoder(x_shuffle, data_pyg.edge_index)
        # Graph pooling
        graph_emb_aug = self.proj(emb_aug).sum(dim=1)
        graph_emb_shuffle = self.proj(emb_shuffle).sum(dim=1)
        # Calculate the discrimiation loss
        logit = torch.cat((graph_emb_aug, graph_emb_shuffle), dim=0)
        disc_y = torch.cat((torch.zeros(node_num), torch.ones(node_num)), 0).to(logit.device)
        return self.bce_loss(logit, disc_y)
    
    def forward(self,
                data_pyg_v1,
                data_pyg_v2,
                exter_proxy: torch.Tensor, 
                pseudo_labels: torch.Tensor):
        # Get the node embeddings
        emb_v1 = self.proj(self.encoder(data_pyg_v1.x, data_pyg_v1.edge_index))
        emb_v2 = self.proj(self.encoder(data_pyg_v2.x, data_pyg_v2.edge_index))
        # compute the losses
        loss_dp = 0.5 * (
            (loss_fn(emb_v1, self.inter_proxy[pseudo_labels]) - loss_fn(emb_v1, exter_proxy[pseudo_labels])) + 
            (loss_fn(emb_v2, self.inter_proxy[pseudo_labels]) - loss_fn(emb_v2, exter_proxy[pseudo_labels]))
        )
        loss_reg_con = loss_fn(emb_v1, emb_v2) * self.reg_const
        loss = loss_dp + loss_reg_con
        return loss, loss_dp, loss_reg_con
