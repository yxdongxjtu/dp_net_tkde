# -*- coding: utf-8 -*-
"""
Title:   Graph Node Encoder 
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import Sequential
from typing import List, Optional

from utils.model_helper import get_activation, get_graph_conv


class EncGNN(nn.Module):
    """Graph neural network for encoding nodes."""
    def __init__(self, 
                 in_dim: int,
                 hids_dim: List[int], 
                 out_dim: Optional[int],
                 enc_type: str,
                 dropout: float = 0.5,
                 use_bn: bool = False, 
                 activation: str = 'prelu', 
                 node_norm: bool = False):
        super().__init__()
        # Parameters
        self.in_dim, self.hids_dim, self.out_dim = in_dim, hids_dim, out_dim
        self.enc_type, self.activation, self.dropout = enc_type, activation, dropout
        self.use_bn, self.node_norm = use_bn, node_norm
        # build the graph convolutional layers
        self.enc_convs = self._build_convs()
    
    def _build_convs(self) -> Sequential:
        """Build the convolutional layers."""
        convs = []
        in_dim = self.in_dim
        # Build the convolutional layers
        for hid_dim in self.hids_dim:
            convs.extend([
                (get_graph_conv(in_dim, hid_dim, self.enc_type), 'x, edge_index -> x'),
                (nn.BatchNorm1d(hid_dim, momentum=0.01) if self.use_bn else nn.Identity(), 'x -> x'),
                (get_activation(self.activation), 'x -> x'), 
                (nn.Dropout(p=self.dropout), 'x -> x')
            ])
            in_dim = hid_dim
        # Build the output layer
        if self.out_dim is not None:
            convs.extend([
                (get_graph_conv(in_dim, self.out_dim, self.enc_type), 'x, edge_index -> x'),
                (get_activation(self.activation), 'x -> x')
            ])
        return Sequential('x, edge_index', convs)
    
    def forward(self, x: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
        """Forward pass of the encoder."""
        if self.node_norm:
            x = F.normalize(x, p=2, dim=-1)
        # Forward pass
        emb = self.enc_convs(x, edge_index)
        return emb
